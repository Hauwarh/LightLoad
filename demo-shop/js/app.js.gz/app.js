// FreshMart app logic. This is the only script the pages actually need.
var PRODUCTS = [
  { id: "rice", name: "Long Grain Rice (5kg)", price: 9500, img: "img/rice.webp" },
  { id: "beans", name: "Honey Beans (2kg)", price: 4200, img: "img/beans.webp" },
  { id: "garri", name: "Ijebu Garri (2kg)", price: 2800, img: "img/garri.webp" },
  { id: "palm-oil", name: "Palm Oil (1L)", price: 3100, img: "img/palm-oil.webp" },
  { id: "tomatoes", name: "Fresh Tomatoes (basket)", price: 6000, img: "img/tomatoes.webp" },
  { id: "yam", name: "Yam Tuber", price: 3500, img: "img/yam.webp" }
];
function naira(n) { return "₦" + n.toLocaleString("en-NG"); }
function getCart() { try { return JSON.parse(localStorage.getItem("cart") || "[]"); } catch (e) { return []; } }
function setCart(c) { localStorage.setItem("cart", JSON.stringify(c)); updateCount(); }
function addToCart(id) {
  var c = getCart(); c.push(id); setCart(c);
  var n = document.getElementById("added"); if (n) { n.textContent = "Added to cart"; n.hidden = false; }
}
function updateCount() { var n = getCart().length; var el = document.getElementById("cart-count"); if (el) el.textContent = n;
  var all = document.querySelectorAll(".cart-count"); for (var i = 0; i < all.length; i++) all[i].textContent = n; }
function card(p) {
  return '<div class="card"><a class="card-img" href="product.html?id=' + p.id + '"><img loading="lazy" decoding="async" width="320" height="320" src="' + p.img + '" alt="' + p.name + '"></a>' +
    '<div class="card-body"><h3>' + p.name + '</h3><span class="price">' + naira(p.price) + '</span>' +
    '<button onclick="addToCart(\'' + p.id + '\')">Add to cart</button></div></div>';
}
function q(name) { return new URLSearchParams(location.search).get(name) || ""; }
document.addEventListener("DOMContentLoaded", function () {
  updateCount();
  var page = document.body.getAttribute("data-page");
  if (page === "home") document.getElementById("products").innerHTML = PRODUCTS.map(card).join("");
  if (page === "search") {
    var term = q("q").toLowerCase();
    document.getElementById("q").value = q("q");
    var hits = PRODUCTS.filter(function (p) { return p.name.toLowerCase().indexOf(term) !== -1; });
    document.getElementById("results").innerHTML = hits.length ? hits.map(card).join("") : "<p>No results for " + term + "</p>";
  }
  if (page === "product") {
    var p = PRODUCTS.filter(function (x) { return x.id === q("id"); })[0] || PRODUCTS[0];
    document.getElementById("product").innerHTML = '<img width="320" height="320" src="' + p.img + '" alt="' + p.name + '">' +
      '<h1>' + p.name + '</h1><p><span class="price">' + naira(p.price) + '</span></p><button class="btn-block" onclick="addToCart(\'' + p.id + '\')">Add to cart</button>';
  }
  if (page === "cart" || page === "checkout") {
    var items = getCart().map(function (id) { return PRODUCTS.filter(function (x) { return x.id === id; })[0]; }).filter(Boolean);
    var total = items.reduce(function (s, p) { return s + p.price; }, 0);
    document.getElementById("lines").innerHTML = items.length
      ? items.map(function (p) { return '<div class="cart-line"><span>' + p.name + '</span><span>' + naira(p.price) + '</span></div>'; }).join("") +
        '<div class="cart-line"><strong>Total</strong><strong>' + naira(total) + '</strong></div>'
      : "<p>Your cart is empty.</p>";
  }
});
